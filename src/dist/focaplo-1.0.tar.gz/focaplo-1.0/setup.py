from distutils.core import setup
setup(name='focaplo',
      version='1.0',
      packages=['focaplo','focaplo.files','focaplo.haproxy','focaplo.bime','focaplo.messaging','focaplo.os','focaplo.ec2'],
      )